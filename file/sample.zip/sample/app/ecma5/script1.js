function call1(name) {  
    for (n =0;n<=5;n++){ 
        portdic.set("room1","BulbOnOff","On") 
        portdic.sleep(1000); 
        portdic.set("room1","BulbOnOff","Off") 
        console.log(n); 
    }
    console.log("done"); 
}  

function call2(name) {  
    for (n =0;n<=5;n++){ 
        portdic.set("room1","BulbOnOff","On") 
        portdic.sleep(1000); 
        portdic.set("room1","BulbOnOff","Off") 
        console.log(n); 
    }
    console.log("done"); 
}  

function call3(name) {  
    for (n =0;n<=5;n++){ 
        portdic.set("room1","BulbOnOff","On") 
        portdic.sleep(1000); 
        portdic.set("room1","BulbOnOff","Off") 
        console.log(n); 
    }
    console.log("done"); 
}  

function alert(message){
    portdic.alert("test",message)
}

function main(){
    portdic.flow(call1("test"),call2("test"),call3("test"))
}