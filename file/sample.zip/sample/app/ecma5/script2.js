function sum(a, b) {
    return +a + b;
}


function mat(a, b) {
    return a * b;
}

function get(a,b) { 
    return portdic.Get(a,b);
}

function set(a,b,c) { 
    return portdic.Set(a,b,c);
}