import Bulb1 from `BulbLib1`
import Bulb2 from `BulbLib2`
import Bulb3 from `BulbLib3` 
import Heater1 from `HeaterLib1`
import Heater2 from `HeaterLib2`
import Heater3 from `HeaterLib3`
 
function boot(){ 
    if (!Bulb1.Valid()){
        console.log("invalid Bulb1")
        return false;
    } 
    
    if (!Bulb2.Valid()){
        console.log("invalid Bulb2")
        return false;
    } 
    
    if (!Bulb3.Valid()){
        console.log("invalid Bulb3")
        return false;
    } 
    
    if (!Heater1.Valid()){
        console.log("invalid Heater1")
        return false;
    } 
    
    if (!Heater2.Valid()){
        console.log("invalid Heater2")
        return false;
    } 
    
    if (!Heater3.Valid()){
        console.log("invalid Heater3")
        return false;
    }  
    
    return true;
}