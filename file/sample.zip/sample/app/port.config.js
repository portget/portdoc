const Config = { 
    ignore:{
      case:false,
      ng:false,
    },
    listen:{
      port:5001,
    },
    mqtt:{
      allowlist:["0.0.0.0:5000","0.0.0.0:5001"],
      clients: [{"name":"admin","password":"admin"}],
    },
    echo:{
      port:23,
    },
    ssh:{
      port:22,
    },
    gettrigger:{
      used:false,
      delay:3000,
    },
    settrigger:{
      used:false,
      delay:1000,
    },
};

export default Config;